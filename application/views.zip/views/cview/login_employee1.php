<div class="container">
    <!-----------content left------------------->
    <div class="login-container">
    	<div style="padding-left:5px;">
            <h2><b>Login Employee Text</b></h2>
            <p>No 9, St, 310, Sangkat Keng Kang !,</p>
            <p>khan chomarmorn, Phnom Phen</p>
        </div>
    </div>
    <!----------------End Content Left------------------>
    
    <!-------------Recruitment Right------------------->
    <div class="panel-left-login" style="margin:15px 0px;">
    	<section id="content">
            <form action="">
                <h1>Login Form</h1>
                <div>
                    <input type="text" placeholder="E-mail" required id="username" />
                </div>
                <div>
                    <input type="password" placeholder="Password" required id="password" />
                </div>
                <div>
                    <input type="submit" value="Log in" />
                    <a href="#">Lost your password?</a>
                    <a href="#">Register</a>
                </div>
            </form>
            <a href="#">
            <img class="img-responsive" src="<?=base_url('image/fac1.png');?>" style="border-radius:5px; height:50px; width:80%; margin-bottom:15px;">
            </a>
        </section>
    </div>
    <!-------------End Recruitment Right------------------->
</div>