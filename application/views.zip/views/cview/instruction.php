<div class="container" style="margin-top:10px;">

    <div class="col-lg-12 col-md-12 col-sm-12" style="margin-top:15px;">
    	<?php
			 foreach($get_instruction as $contact){
				echo $contact->ins_description;
				
			}
		 ?>
    </div>
 </div>